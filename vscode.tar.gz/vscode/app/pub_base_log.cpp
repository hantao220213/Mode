#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<fcntl.h>
#include<stdint.h>
#include<sys/time.h>
#include<stdarg.h>
#include<time.h>
#include "pub_log.h"
#include "pub_global.h"

u_char *ngx_slprintf(u_char *buf, u_char *last, const char *fmt, ...) 
{
    va_list   args;
    u_char   *p;

    va_start(args, fmt); //使args指向起始的参数
    p = ngx_vslprintf(buf, last, fmt, args);
    va_end(args);        //释放args   
    return p;
}
u_char *ngx_vslprintf(u_char *buf, u_char *last,const char *fmt,va_list args)
{    
    u_char     zero;

    uintptr_t  width,sign,hex,frac_width,scale,n;  
    int64_t    i64;   
    uint64_t   ui64; 
    u_char     *p;   
    double     f;    
    uint64_t   frac;  
    

    while (*fmt && buf < last) 
    {
        if (*fmt == '%')
        {
            zero  = (u_char) ((*++fmt == '0') ? '0' : ' ');   
                                                                
            width = 0;                                      
            sign  = 1;                                      
            hex   = 0;                                       
            frac_width = 0;                                
            i64 = 0;                                        
            ui64 = 0;                                            
            
       
            while (*fmt >= '0' && *fmt <= '9')
            {
                width = width * 10 + (*fmt++ - '0');
            }

            for ( ;; ) 
            {
                switch (*fmt) 
                {
                case 'u':      
                    sign = 0;  
                    fmt++;     
                    continue;   

                case 'X':      
                    hex = 2;   
                    sign = 0;
                    fmt++;
                    continue;
                case 'x':       
                    hex = 1;    
                    sign = 0;
                    fmt++;
                    continue;

                case '.':       
                    fmt++;    
                    while(*fmt >= '0' && *fmt <= '9') 
                    {
                        frac_width = frac_width * 10 + (*fmt++ - '0'); 
                    } //end while(*fmt >= '0' && *fmt <= '9') 
                    break;

                default:
                    break;                
                } //end switch (*fmt) 
                break;
            } //end for ( ;; )

            switch (*fmt) 
            {
            case '%': 
                *buf++ = '%';
                fmt++;
                continue;

            case 'd':
                if (sign)  
                {
                    i64 = (int64_t) va_arg(args, int);  
                }
                else 
                {
                    ui64 = (uint64_t) va_arg(args, u_int);    
                }
                break;  

            case 's': 
                p = va_arg(args, u_char *); 

                while (*p && buf < last)  
                {
                    *buf++ = *p++;  
                }
                
                fmt++;
                continue; 

            case 'P':  
                i64 = (int64_t) va_arg(args, pid_t);
                sign = 1;
                break;

            case 'f':   
                f = va_arg(args, double); 
                if (f < 0)  //负数的处理
                {
                    *buf++ = '-'; //单独搞个负号出来
                    f = -f; //f应该是正数了!
                }
                ui64 = (int64_t) f;
                frac = 0;

                if (frac_width) 
                {
                    scale = 1; 
                    for (n = frac_width; n; n--) 
                    {
                        scale *= 10; 
                    }

                    
                    frac = (uint64_t) ((f - (double) ui64) * scale + 0.5);  

                    if (frac == scale)   
                    {
                        ui64++;    
                        frac = 0;  
                    }
                
                } //end if (frac_width)

                //正整数部分，先显示出来
                buf = ngx_sprintf_num(buf, last, ui64, zero, 0, width);

                if (frac_width) 
                {
                    if (buf < last) 
                    {
                        *buf++ = '.';
                    }
                    buf = ngx_sprintf_num(buf, last, frac, '0', 0, frac_width);
                }
                fmt++;
                continue;  


            default:
                *buf++ = *fmt++; 
                continue; 
            }  
            
          
            if (sign) 
            {
                if (i64 < 0)  
                {
                    *buf++ = '-';  
                    ui64 = (uint64_t) -i64; 
                }
                else 
                {
                    ui64 = (uint64_t) i64;
                }
            } //end if (sign) 

           
            buf = ngx_sprintf_num(buf, last, ui64, zero, hex, width); 
            fmt++;
        }
        else  
        {
            *buf++ = *fmt++; 
        } //end if (*fmt == '%') 

    }  //end while (*fmt && buf < last) 
    
    return buf;
}

static u_char * ngx_sprintf_num(u_char *buf, u_char *last, uint64_t ui64, u_char zero, uintptr_t hexadecimal, uintptr_t width)
{
    //temp[21]
    u_char      *p, temp[NGX_INT64_LEN + 1];   
    size_t      len;
    uint32_t    ui32;

    static u_char   hex[] = "0123456789abcdef";  
    static u_char   HEX[] = "0123456789ABCDEF";  

    p = temp + NGX_INT64_LEN; 
    if (hexadecimal == 0)  
    {
        if (ui64 <= (uint64_t) NGX_MAX_UINT32_VALUE)
        {
            ui32 = (uint32_t) ui64; 
            do  
            {
                *--p = (u_char) (ui32 % 10 + '0');  
            }
            while (ui32 /= 10); 
        }
        else
        {
            do 
            {
                *--p = (u_char) (ui64 % 10 + '0');
            } while (ui64 /= 10); 
        }
    }
    else if (hexadecimal == 1)  
    {
        do 
        {            
            *--p = hex[(uint32_t) (ui64 & 0xf)];    
        } while (ui64 >>= 4);    
                                
    } 
    else 
    { 
        do 
        { 
            *--p = HEX[(uint32_t) (ui64 & 0xf)];
        } while (ui64 >>= 4);
    }

    len = (temp + NGX_INT64_LEN) - p; 

    while (len++ < width && buf < last) 
    {
        *buf++ = zero;  
    }
    
    len = (temp + NGX_INT64_LEN) - p;

    if((buf + len) >= last)   
    {
        len = last - buf;
    }

    return ngx_cpymem(buf, p, len); 
}

