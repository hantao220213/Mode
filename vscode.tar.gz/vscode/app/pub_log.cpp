#include "pub_global.h"
#include "pub_log.h"
#include "pub_config.h"
#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<fcntl.h>
#include<stdint.h>
#include<sys/time.h>
#include<stdarg.h>
#include<time.h>

static u_char err_levels[][20]  = 
{
    {"stderr"},    //0：控制台错误
    {"emerg"},     //1：紧急
    {"alert"},     //2：警戒
    {"crit"},      //3：严重
    {"error"},     //4：错误
    {"warn"},      //5：警告
    {"notice"},    //6：注意
    {"info"},      //7：信息
    {"debug"}      //8：调试
};

log_t ngx_log;

void ngx_log_stderr(int err, const char *fmt, ...)
{    
    va_list args;                        
    u_char  errstr[NGX_MAX_ERROR_STR+1];  
    u_char  *p,*last;

    memset(errstr,0,sizeof(errstr));    

    last = errstr + NGX_MAX_ERROR_STR;       
                                              
                                                
    p = ngx_cpymem(errstr, "ngx_svr: ", 9);    
    
    va_start(args, fmt); //使args指向起始的参数
    p = ngx_vslprintf(p,last,fmt,args);
    va_end(args);        //释放args

    if (err)  //如果错误代码不是0，表示有错误发生
    {
        p = ngx_log_errno(p, last, err);
    }
    
    //若位置不够，那换行也要硬插入到末尾，哪怕覆盖到其他内容
    if (p >= (last - 1))
    {
        p = (last - 1) - 1; //把尾部空格留出来 
                           
    }
    *p++ = '\n';   

    //往标准错误输出信息    
    write(STDERR_FILENO,errstr,p - errstr); 
    if(ngx_log.fd > STDERR_FILENO){
        ngx_log_error_core(NGX_LOG_STDERR,errno," 输出屏幕信息 errstr :  %s",errstr);
    }
   
    
    return;
}

//----------------------------------------------------------------------------------------------------------------------
//buf：是个内存，要往这里保存数据
//last：放的数据不要超过这里
//err：错误编号，我们是要取得这个错误编号对应的错误字符串，保存到buffer中
u_char *ngx_log_errno(u_char *buf, u_char *last, int err)
{
    char *perrorinfo = strerror(err); 
    size_t len = strlen(perrorinfo);

    char leftstr[10] = {0}; 
    sprintf(leftstr," (%d: ",err);
    size_t leftlen = strlen(leftstr);

    char rightstr[] = ") "; 
    size_t rightlen = strlen(rightstr);
    
    size_t extralen = leftlen + rightlen; //左右的额外宽度
    if ((buf + len + extralen) < last)
    {
        buf = ngx_cpymem(buf, leftstr, leftlen);
        buf = ngx_cpymem(buf, perrorinfo, len);
        buf = ngx_cpymem(buf, rightstr, rightlen);
    }
    return buf;
}

//----------------------------------------------------------------------------------------------------------------------
//level:一个等级数字,日志分成一些等级，以方便管理、显示、过滤等等
//err：是个错误代码，如果不是0，就应该转换成显示对应的错误信息,一起写到日志文件中，
//ngx_log_error_core(5,8,"这个XXX工作的有问题,显示的结果是=%s","YYYY");
void ngx_log_error_core(int level,  int err, const char *fmt, ...)
{
    u_char  *last;
    u_char  errstr[NGX_MAX_ERROR_STR+1];   

    memset(errstr,0,sizeof(errstr));  
    last = errstr + NGX_MAX_ERROR_STR;   
    
    struct timeval   tv;
    struct tm        tm;
    time_t           sec;   //秒
    u_char           *p;    //指向当前要拷贝数据到其中的内存位置
    va_list          args;

    memset(&tv,0,sizeof(struct timeval));    
    memset(&tm,0,sizeof(struct tm));

    gettimeofday(&tv, NULL);           

    sec = tv.tv_sec;            
    localtime_r(&sec, &tm);      
    tm.tm_mon++;                
    tm.tm_year += 1900;         
    
    u_char strcurrtime[40]={0};  
    ngx_slprintf(strcurrtime,  
                    (u_char *)-1,                      
                    "%4d/%02d/%02d %02d:%02d:%02d",    
                    tm.tm_year, tm.tm_mon,
                    tm.tm_mday, tm.tm_hour,
                    tm.tm_min, tm.tm_sec);
    p = ngx_cpymem(errstr,strcurrtime,strlen((const char *)strcurrtime)); 
    p = ngx_slprintf(p, last, " [%s] ", err_levels[level]);                
    p = ngx_slprintf(p, last, "%P: ",ngx_pid);                            

    va_start(args, fmt);                     
    p = ngx_vslprintf(p, last, fmt, args);  
    va_end(args);                             

    if (err)  
    {
        
        p = ngx_log_errno(p, last, err);
    }
  
    if (p >= (last - 1))
    {
        p = (last - 1) - 1; 
                             
    }
    *p++ = '\n';     

    ssize_t   n;
    while(1) 
    {        

        if (level > ngx_log.log_level) 
        {
   
            break;
        }

        //写日志文件        
        n = write(ngx_log.fd,errstr,p - errstr);  //文件写入成功后，如果中途
        if (n == -1) 
        {
            //写失败有问题
            if(errno == ENOSPC) //写失败，原因是磁盘没空间了
            {
                //磁盘没空间了
                //没空间还写个毛线啊
            }
            else
            {
                if(ngx_log.fd != STDERR_FILENO) //当前是定位到文件的，则条件成立
                {
                    n = write(STDERR_FILENO,errstr,p - errstr);
                }
            }
        }
        break;
    } //end while  
    return;
}

//----------------------------------------------------------------------------------------------------------------------
//描述：日志初始化，日志文件打开 
void ngx_log_init()
{
    u_char *plogname = NULL;
    size_t nlen;

    //从配置文件中读取和日志相关的配置信息
    CConfig *p_config = CConfig::GetInstance();
    plogname = (u_char *)p_config->GetString("Log");
    if(plogname == NULL)
    {
        //没读到，就要给个缺省的路径文件名了
        plogname = (u_char *) NGX_ERROR_LOG_PATH; 
    }
    ngx_log.log_level = p_config->GetInitDefualt("LogLevel",NGX_LOG_NOTICE);

    ngx_log.fd = open((const char *)plogname,O_WRONLY|O_APPEND|O_CREAT,0644);  
    if (ngx_log.fd == -1)  
    {
        ngx_log_stderr(errno,"[alert] could not open error log file: open() \"%s\" failed", plogname);
        ngx_log.fd = STDERR_FILENO;         
    } 
    return;
}
