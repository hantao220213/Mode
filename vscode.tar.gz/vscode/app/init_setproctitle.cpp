#include "pub_global.h"
#include<unistd.h>
#include<stdio.h>
#include<string.h>
void init_setproctitle(){

    
    g_penvmem = new char[g_environlen+1];
    memset(g_penvmem,0,g_environlen);
    char *ptmp=g_penvmem;
    for (size_t i = 0; environ[i]; i++)
    {
        /* code */
        int len = strlen(environ[i]);
        memcpy(ptmp,environ[i],len);
        environ[i]=ptmp;
        ptmp+=(len+1);
    }
    return;
}

void set_proctitle(const char *title){
    //ngx_log_stderr(0,"1set title [%s]",title);
    int sizetitle = strlen(title);
    int sz = argvlen+g_environlen;
    //ngx_log_stderr(0," 2set sizetitle [%d]",sizetitle);

    if(sz<=sizetitle)
        return;
    g_os_argv[1]=NULL;
    char *ptmp = g_os_argv[0];
 
    //ngx_log_stderr(0," 3set  ptmp title [%s]",ptmp);
    memcpy(ptmp,title,sizetitle);

    //ngx_log_stderr(0," 4set  ptmp title [%s]",ptmp);
    ptmp+=sizetitle;
    //ngx_log_stderr(0," 5set  ptmp title [%s]",ptmp);

    int szn = sz-sizetitle;
    memset(ptmp,0,szn);

    return;
}