#include<stdio.h>
#include "pub_config.h"
#include<stdlib.h>
#include<string.h>

void config(){

}

CConfig *CConfig::m_instance=NULL;

CConfig::CConfig()
{
}

CConfig::~CConfig()
{
    
    if(!itemConfigList.empty()){
        vector<pItemConfig>::iterator it;
        for(it= itemConfigList.begin();it!=itemConfigList.end();it++){
            delete *it;
        }
        itemConfigList.clear();
    }
    
}


bool CConfig::load(const char *pfileName){
    FILE *fp=NULL;
    fp = fopen(pfileName,"r");
    if(fp == NULL)
        return false;
    char lineData[512]={0};
    while (!feof(fp))
    {
        /* code */
        if(fgets(lineData,sizeof(lineData)/sizeof(char)-1,fp) == NULL)
            continue;
        if(lineData[0] == 0)
            continue;
        
        if(*lineData==';' || *lineData==' ' || *lineData=='#' || *lineData=='\t'|| *lineData=='\n')
            continue;

        loop:
        if(strlen(lineData) >0){
            if(lineData[strlen(lineData)-1]==10||lineData[strlen(lineData)-1]==13||lineData[strlen(lineData)-1]==32)
            {
                lineData[strlen(lineData)-1]=0;
                goto loop;
            }
        }
        if(lineData[0]==0)
            continue;
        if(*lineData == '[')
            continue;
        
        char *p = strchr(lineData,'=');
        if(p != NULL){
            pItemConfig pconfg = new ItemConfig;
            memset(pconfg,0,sizeof(ItemConfig));
            memcpy(pconfg->itemName,lineData,p-lineData);
            strcpy(pconfg->itemValue,p+1);

            Ltrim(pconfg->itemValue);
            Rtrim(pconfg->itemValue);

            Ltrim(pconfg->itemName);
            Rtrim(pconfg->itemName);

            itemConfigList.push_back(pconfg);
        
        }

    }
    
    fclose(fp);

    return true;
}

const char *CConfig::GetString(const char *itemName){

    vector<pItemConfig>::iterator it;
    for (it=itemConfigList.begin();it!=itemConfigList.end();++it){
        if(strcasecmp((*it)->itemName,itemName)==0)
            return (*it)->itemValue;
    }

    return NULL;
}

int CConfig::GetInitDefualt(const char *itemName,int def){
    vector<pItemConfig>::iterator it;
    for (it=itemConfigList.begin();it!=itemConfigList.end();++it){
        if(strcasecmp((*it)->itemName,itemName)==0)
            return atoi((*it)->itemValue);
    }

    return def;
}