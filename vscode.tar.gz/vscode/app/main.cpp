#include <stdio.h>
#include<string.h>
#include<iostream>
#include "pub_config.h"
#include "pub_signal.h"
#include "pub_log.h"
#include "pub_global.h"
#include <signal.h>
#include "pub_socket.h"
using namespace  std;

char **g_os_argv;
char *g_penvmem = NULL;
int g_environlen=0;
int argvlen=0;
int g_os_argc=0;

pid_t ngx_pid;
pid_t parent_pid;
int process_type; //进程 master or work
sig_atomic_t work_precess_reap; 

int g_daemonzed=0; //守护进程启用标识，0-未启用，1-启用

CSockt g_socket;

void deleteSource();
int main(int argc,char *argv[]){

   
    int listenport=0;
    const char *dbinfo =NULL;
    const char *logfile=NULL;
    int level=0;
    g_os_argv=argv;
    g_os_argc=argc;
    ngx_pid =getgid();
    parent_pid=getppid();

    ngx_log.fd=-1;
    process_type=PROCESS_MASTER;
    work_precess_reap=0;

   //统计环境变量所占的内存
    for (size_t i = 0;environ[i]; i++)
    {
        /* code */
        g_environlen+=strlen(environ[i])+1;
    }

    //统计argv所占的内存  
    for (size_t i = 0; g_os_argv[i]; i++)
    {
        /* code */
        argvlen+=strlen(g_os_argv[i])+1;
    }


    

    CConfig *pInstance = CConfig::GetInstance();
    if((pInstance->load("config.ini"))==false){

        ngx_log_stderr(0,"配置文件[%s]载入失败，退出!","nginx.conf");
        goto delS;
    }

    //初始化日志
     ngx_log_init();

    //初始化信号集
     if(init_signals() <0)
    {
        ngx_log_stderr(0,"初始化信号量失败，退出! [%s]","init_signals");
        goto delS;
    }

    if(g_socket.Initialize() == false){
        ngx_log_stderr(0," 初始化绑定端口失败");
        goto delS;
    }

    init_setproctitle();
    
    /*
    listenport = pInstance->GetInitDefualt("listenport",8081);
    ngx_log_stderr(0,"listen port: %d",listenport);
    ngx_log_error_core(NGX_LOG_EMERG,errno,"listen port: %d",listenport);

    dbinfo = pInstance->GetString("dbinfo");
    ngx_log_stderr(0,"dbinfo: %s",dbinfo);
    ngx_log_error_core(NGX_LOG_EMERG,errno,"dbinfo: %s",dbinfo);

    logfile = pInstance->GetString("Log");
    ngx_log_stderr(0,"Log: %s",logfile);
    ngx_log_error_core(NGX_LOG_EMERG,errno,"logfile: %s",logfile);

    level = pInstance->GetInitDefualt("LogLevel",6);
    ngx_log_stderr(0,"level: %d",level);
    ngx_log_error_core(NGX_LOG_EMERG,errno,"level: %d",level);
    */

    //创建守护进程
    if((pInstance->GetInitDefualt("Daemon",0)) ==1){
        int daemonFalg = project_daemon();
        if(daemonFalg  == 1){
            ngx_log_error_core(NGX_LOG_EMERG,errno," 守护进程正常退出");
            goto delS;
         }
         if(daemonFalg == -1){
            ngx_log_error_core(NGX_LOG_EMERG,errno," 创建守护进程失败");
            goto delS;
         }
        g_daemonzed=1;
    }

    //创建工作进程
    master_process_cycle();

    //set_proctitle("ngx_svr: master process");


/*
    while (true)
    {
      
        sleep(2);
        cout<<" master sleep 1 seconds"<<endl;
    }
    
*/

delS:
    deleteSource();
    return 0;
}
void deleteSource(){
    if(g_penvmem){
        delete g_penvmem;
        g_penvmem=NULL;
    }

    if(ngx_log.fd != -1||ngx_log.fd != STDERR_FILENO){
        close(ngx_log.fd);
        ngx_log.fd=-1;

    }
}