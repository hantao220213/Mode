#include "pub_socket.h"
#include "pub_log.h"
#include "pub_global.h"
#include <string.h>

lpconnect_t CSockt::get_connection(int sockfd)
{
    lpconnect_t c = m_pfree_connctions;
    if(c == NULL)
    {
        ngx_log_stderr(0," 空闲链表为空,这不应该!");
        return NULL;
    }

    m_pfree_connctions =c->data;
    m_free_connctions_n--; 
    uintptr_t instance = c->instance; 
    int iCurrsequence = c->iCurrsequence;
    memset(c,0,sizeof(connect_t));

    c->fd=sockfd; 
    c->instance=!instance; 
    c->iCurrsequence=iCurrsequence; 
    ++(c->iCurrsequence);
    return c;
}

void CSockt::free_connection(lpconnect_t c)
{
    c->data=m_pfree_connctions; 
    ++c->iCurrsequence;        
    m_pfree_connctions=c;     
    ++m_pfree_connctions;     

}
