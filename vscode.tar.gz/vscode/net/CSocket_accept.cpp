#include "pub_socket.h"
#include "pub_global.h"
#include "pub_log.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>


void CSockt::event_accept(lpconnect_t oldc)
{

    struct sockaddr mysockaddr;
    socklen_t       socklen;
    int             err;
    int             level;
    int             use_accept4=1; //使用accept4
    int             isock; //aceept 
    lpconnect_t     newconnect; //连接池中的一个连接

    socklen = sizeof(mysockaddr);
    do
    {
        if(use_accept4)
        {
            isock = accept4(oldc->fd,(struct sockaddr *)&mysockaddr,&socklen,SOCK_NONBLOCK);
        }
        else
        {
            isock = accept(oldc->fd,(struct sockaddr * )&mysockaddr,&socklen);
        }

        if(isock == -1)
        {
            err = errno;
            if(err == EAGAIN) ////accept()没准备好
            {
                return;
            }
            level = NGX_LOG_ALERT;
            if(err == ECONNABORTED) //ECONNRESET错误则发生在对方意外关闭套接字后,主动放弃连接
            {
                level = NGX_LOG_ERR;
            }
            else if(err == EMFILE || err == ENFILE) 
            {
                level == NGX_LOG_CRIT;
            }
            ngx_log_error_core(level,err,"CSocket::accept 失败");
            if(use_accept4 && err == ENOSYS) 
            {
                use_accept4=0;//用accept()函数
                continue;     
            }
            if (err == ECONNABORTED)  //对方关闭套接字
            {
                ngx_log_error_core(level,err,"CSocket::accept /对方关闭套接字");
            }
            
            if (err == EMFILE || err == ENFILE) 
            {
                ngx_log_error_core(level,err,"CSocket::accept 失败");

            } 
            return ;
        }//end if(isock == -1)

        newconnect = get_connection(isock);
        if(newconnect == NULL)
        {
            if(close(isock) == -1)
            {
                ngx_log_error_core(NGX_LOG_CRIT,errno," event_accept close 失败 isock [%d]",isock);
            }
            return ;
        }

        //这里会判断是否连接超过最大允许连接数，现在，这里可以不处理,或则返回错,或者不控制*/
        /*

        */

        if(m_free_connctions_n == 0)
        {
            ngx_log_error_core(NGX_LOG_CRIT,0,"连接以满[%d]",m_free_connctions_n);
            return;
        }

        //成功的拿到了连接池中的一个连接
        memcpy(&newconnect->s_sockaddr,&mysockaddr,sizeof(mysockaddr));
        if(!use_accept4)
        {
            if(setnoblocking(isock) == -1)
            {
                ngx_log_error_core(NGX_LOG_CRIT,errno," event_accept 中setnoblocking 失败!!!");
                close_accept_connection(newconnect);
                return ;
            }
        }

        newconnect->listening=oldc->listening; 
        newconnect->w_ready=1;  
        newconnect->rhandler=&CSockt::wait_rquest_handler; 

        if(epoll_add_event(isock,
                            1,0,
                            EPOLL_CTL_ADD,
                            newconnect,
                            EPOLLET /*【EPOLLET(高速模式，边缘触发ET)】*/
                            ) == -1)
        {
            ngx_log_error_core(NGX_LOG_ERR,0," event_epoll 中新增apoll_add_event 失败!!!");
            close_accept_connection(newconnect);
            return;
        }

        break;
    }while (1); //end do{}while
     
  
    return ;
}

void CSockt::close_accept_connection(lpconnect_t newconnection)
{
    int fd = newconnection->fd;
    free_connection(newconnection);
    newconnection->fd=-1;
    if(close(fd) == -1)
    {
        ngx_log_error_core(NGX_LOG_WARN,errno,"close_accept_connection  close(fd)失败[%d]",fd);
    }
    return;
}
