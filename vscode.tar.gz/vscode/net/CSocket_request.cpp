#include "pub_socket.h"
#include "pub_log.h"
#include "pub_global.h"

void CSockt::wait_rquest_handler(lpconnect_t newconn)
{

    ngx_log_error_core(0,0,"wait_rquest_handler");
    return;
}