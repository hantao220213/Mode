#include "pub_global.h"
#include "pub_socket.h"
#include "pub_config.h"
#include "pub_log.h"
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>

CSockt::CSockt(){
    m_WorkConnections=1; //默认epoll连接数为1
    m_ListenPortCount=1; //默认监听一个端口

    m_epollhandle=-1; //epoll返回的句柄
    m_pconnctions=NULL; //连接池【连接数组】先给空
    m_pfree_connctions=NULL; //连接池中空闲的连接链
   
}
CSockt::~CSockt(){

    //监听端口信息释放
    vector<lplisten_t>::iterator pos;
    for(pos = m_ListenSocketList.begin();pos!=m_ListenSocketList.end();++pos){
        delete (*pos);
    }

    //释放连接池数组
    if(m_pconnctions)
        delete []m_pconnctions;

}

bool CSockt::Initialize(){
    ReadConfig();
    bool rc = open_listening_socket();
    return rc;
}

void CSockt::ReadConfig(){
    CConfig *pconf = CConfig::GetInstance();

    m_WorkConnections =pconf->GetInitDefualt("worker_connections",m_WorkConnections);
    m_ListenPortCount=pconf->GetInitDefualt("ListenPortCount",m_ListenPortCount);
    return;
}

bool CSockt::open_listening_socket(){
    int     isocket;
    struct  sockaddr_in server_addr;
    int     port;
    char    strinfo[64]={0};

    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);

    CConfig *pconf = CConfig::GetInstance();
    for(int i = 0;i<m_ListenPortCount;++i)
    {
        //创建socket
        isocket = socket(AF_INET,SOCK_STREAM,0);
        if(-1 == isocket){
            ngx_log_stderr(errno,"创建socket 失败");
            close(isocket);
            return false;
        }

        //设置端口复用
        int readdr = 1;
        if(setsockopt(isocket,SOL_SOCKET,SO_REUSEADDR,&readdr,sizeof(readdr)) == -1)
        {
            ngx_log_stderr(errno,"setsockopt 设置端口复用失败");
            close(isocket);
            return false;
        }
        //设置非阻塞IO
        if(setnoblocking(isocket) == false)
        {
            ngx_log_stderr(errno," setnoblocking 设置非阻塞IO失败");
            close(isocket);
            return false;
        }

        //绑定端口
        sprintf(strinfo,"listenport%d",i);
        port = pconf->GetInitDefualt(strinfo,6789);
        if(bind(isocket,(struct sockaddr *)&server_addr,sizeof(server_addr)) == -1){
            ngx_log_stderr(errno,"绑定端口【%d】失败",port);
            return false;
        }
        
        //监听端口
        if(listen(isocket,NGX_LISTEN_BACKLOG) == -1)
        {
            ngx_log_stderr(errno," 监听端口【%d】失败",port);
            return false;
        }

        //添加监听到列表中
        lplisten_t plistenitem = new listen_t;
        memset(plistenitem,0,sizeof(listen_t));
        plistenitem->fd=isocket;
        plistenitem->port=port;
        ngx_log_error_core(NGX_LOG_INFO,0,"监听端口【%d】成功",port);
        m_ListenSocketList.push_back(plistenitem);

    }//end for()
    if(m_ListenSocketList.size() <= 0)
    {
        ngx_log_error_core(NGX_LOG_NOTICE,0," 没有任何监听端口");
        return false;
    }
    return true;
}

bool CSockt::setnoblocking(int sockfd){
    int nb = 1; //0-清除，1-设置
    if(ioctl(sockfd,FIONBIO,&nb) == -1) //FIONBIO：设置/清除非阻塞I/O标记：0：清除，1：设置
    {
        return false;
    }
    return true;
}

void CSockt::close_listening_socket(){
    
    for(int i=0;i<m_ListenPortCount;i++)
    {
        ngx_log_error_core(NGX_LOG_INFO,0,"关闭监听端口[%d]",m_ListenSocketList[i]->port);
        close(m_ListenSocketList[i]->fd);

    }
    return ;

}

 int CSockt::epoll_init()
 {
    m_epollhandle = epoll_create(m_WorkConnections);
    if(m_epollhandle == -1)
    {
         ngx_log_stderr(errno," epoll_create 创建epoll句柄失败");
         return -1;
    }

    m_connctions_n=m_WorkConnections;

    m_pconnctions = new connect_t[m_connctions_n];

    int i=m_connctions_n; //连接池数量
    lpconnect_t next = NULL; //下一个连接指针
    lpconnect_t c = m_pconnctions; //连接池首地址

    do{
        i--; //从后向前
        c[i].data=next; 
        c[i].fd=-1;  
        c[i].instance=1; 
        c[i].iCurrsequence=0; 

        next= &c[i]; 

    }while (i); 

    m_pfree_connctions = next; 
    m_free_connctions_n = m_connctions_n; 

    vector<lplisten_t>::iterator pos;

    for(pos =m_ListenSocketList.begin();pos != m_ListenSocketList.end();++pos )
    {
        c= get_connection((*pos)->fd); //从连接池中获取一个空闲连接对象
        if(c == NULL)
        {
            ngx_log_stderr(0," 发生致命错误，连接池为空");
            exit(2);
        }

        c->listening =*pos; 
        (*pos)->connections=c;  
        c->rhandler = &CSockt::event_accept;

        if(epoll_add_event((*pos)->fd, //监听套接字
                        1,0,            //读，写
                        EPOLL_CTL_ADD,  //事件类型
                        c,              //连接池中的连接
                        0) ==-1)        //其他标识
        {
            ngx_log_stderr(0,"epoll_add_event 失败");
            exit(2);
        }
    } //end for
    return 1;
 }
 
 int CSockt::epoll_add_event(int fd,int readevent,int writeevent,int eventtype,lpconnect_t c,int othertype=0)
 {
     struct  epoll_event ev;
     if(readevent == 1)
     {
         ev.events=EPOLLIN|EPOLLRDHUP;
       
     }
     else 
     {

     }
     if(othertype != 0)
     {
         ev.events |= othertype;
     }

     ev.data.ptr=(void*)((uintptr_t)c|c->instance);

     if(epoll_ctl(m_epollhandle,eventtype,fd,&ev) == -1)
     {
        ngx_log_stderr(errno,"CSocekt::ngx_epoll_add_event()中epoll_ctl(%d,%d,%d,%u,%u)失败.",fd,readevent,writeevent,othertype,eventtype);
        return -1;
     }
     return 0;
 }

int CSockt::epoll_process_events(int timer)
{
    int events = epoll_wait(m_epollhandle,m_events,NGX_MAX_EVENTS,timer);
    if(events == -1)
    {
        if(errno == EINTR)
        {
            ngx_log_error_core(NGX_LOG_INFO,errno," epoll_process_events 中epoll_wait 失败");
            return 1;
        }
        else
        {
            //出现错误，记录日志
            ngx_log_error_core(NGX_LOG_ALERT,errno," epoll_process_events 中epoll_wait 失败 ");
            return -1;
        }
    }

    if(events == 0)
    {
        if(timer != -1)
        {
            ngx_log_error_core(NGX_LOG_INFO,0," epoll_process_events中epoll_wait 超时时间到了，正常返回");
            return 1;
        }

        ngx_log_error_core(NGX_LOG_ALERT,0," epoll_process_events中epoll_wait 无限等待,无超时也没有返回任何事件，异常返回");
        return -2;

    }


    ngx_log_error_core(NGX_LOG_INFO,0,"epoll_wait 获取连接信息成功");
    lpconnect_t c ;
    uintptr_t instance;
    uint32_t  revents;

    for(int i=0;i<events;i++)
    {
        c = (lpconnect_t)(m_events[i].data.ptr);
        instance = (uintptr_t)c & 1;
        c = (lpconnect_t)((uintptr_t)c &(uintptr_t)~1); 

        if(c->fd == -1)
        {
            ngx_log_error_core(NGX_LOG_DEBUG,0,"CSocekt::epoll_process_events()中遇到了fd=-1的过期事件:%p.",c); 
            continue;
        }
        //
        if(c->instance != instance)
        {
            ngx_log_error_core(NGX_LOG_DEBUG,0,"CSocekt:: epoll_process_events()中遇到了instance值改变的过期事件:%p.",c);
            continue;
        }


        revents = m_events[i].events;

        if(revents &(EPOLLERR|EPOLLHUP) )
        {
            revents|=EPOLLIN|EPOLLOUT;
        }

        if(revents & EPOLLIN) //读事件
        {
            (this->*(c->rhandler))(c);

        }

        if(revents & EPOLLOUT) //写事件
        {
            ngx_log_error_core(NGX_LOG_INFO,0," EPOLL 写事件");
        }

    }//end for

    return 1;
}