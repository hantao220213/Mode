
#include<signal.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<signal.h>
#include "pub_signal.h"
#include "pub_global.h"
#include "pub_log.h"
#include<sys/wait.h>
typedef struct 
{
	int signo;
	const char *sigName;
	void(*handler)(int signo,siginfo_t *siginfo,void *context);
}ngx_signal_t;

static void ngx_sig_hander(int signo,siginfo_t *siginfo,void *context);
static void process_sig_status();

ngx_signal_t signals[]{
	{ SIGHUP,    "SIGHUP",           ngx_sig_hander },       
    { SIGINT,    "SIGINT",           ngx_sig_hander },          
	{ SIGTERM,   "SIGTERM",          ngx_sig_hander },       
    { SIGCHLD,   "SIGCHLD",          ngx_sig_hander },        
    { SIGQUIT,   "SIGQUIT",          ngx_sig_hander },       
    { SIGIO,     "SIGIO",            ngx_sig_hander },      
    { SIGSYS,    "SIGSYS, SIG_IGN",  NULL               },                                                                        
    { 0,         NULL,               NULL               }       

};

int init_signals(){

	ngx_signal_t *sig;
	struct sigaction sa;
	for (sig=signals;sig->signo!=0;sig++)
	{
		memset(&sa,0,sizeof(struct sigaction));
		if(sig->handler){
			sa.sa_sigaction=sig->handler;
			sa.sa_flags=SA_SIGINFO;
		}
		else{
			sa.sa_handler=SIG_IGN;
		}
		sigemptyset(&sa.sa_mask);

		if(sigaction(sig->signo,&sa,NULL) ==-1){
			ngx_log_error_core(NGX_LOG_EMERG,errno,"sigaction(%s) failed",sig->sigName); 
            return -1;
		}
		else{
            ngx_log_stderr(0,"sigaction(%s) succed!",sig->sigName); 
		}


	}
	return 0;
}
static void  ngx_sig_hander(int signo,siginfo_t *siginfo,void *context){

	ngx_log_stderr(0," 接收到信号");

	ngx_signal_t *sig;
	char *action; 
	for(sig = signals;sig->signo!=0;++sig){
		if(sig->signo == signo)
			break;
	}
	 action = (char *)""; 
	if(process_type == PROCESS_MASTER){
		switch (signo)
		{
		case SIGCHLD: 
			work_precess_reap=1;
			break;
		
		default:
			break;
		}
	}
	if(process_type == PROCESS_WORK){
		switch (signo)
		{
		case SIGQUIT:

			ngx_log_error_core(NGX_LOG_ALERT,errno," 子进程收到： SIGQUIT 信号");
			break;
		
		default:
			break;
		}
	}

	if(siginfo && siginfo->si_pid)
	{
		     ngx_log_error_core(NGX_LOG_NOTICE,0,"signal %d (%s) received from %P%s", signo, sig->sigName, siginfo->si_pid, action); 
	}
	else{
		        ngx_log_error_core(NGX_LOG_NOTICE,0,"signal %d (%s) received %s",signo, sig->sigName, action);
	}

	if(signo == SIGCHLD){
		process_sig_status();
	}
	
	return ;
}
static void process_sig_status(){
	pid_t pid;
	int status;
	int err;
	int one=0;
	for(;;){
		pid = waitpid(-1,&status,WNOHANG);
		if(pid == 0)
		{
			return ;//子进程未结束
		}
		if(pid == -1)
		{
			err = errno;
			if(err = EINTR)
			{
				continue ;//信号被打断
			}
			if(err == ECHILD && one){
				return ;//没有子进程
			}
			if(err == ECHILD ){
				ngx_log_error_core(NGX_LOG_INFO,err," waitpid 失败");
				return ;//没有子进程
			}
			ngx_log_error_core(NGX_LOG_INFO,errno, " waitpid 失败" );

		}//end if
		one=1;
		if(WTERMSIG(status)){
            ngx_log_error_core(NGX_LOG_ALERT,0,"pid = %P exited on signal %d!",pid,WTERMSIG(status)); 
		}
		else{
            ngx_log_error_core(NGX_LOG_NOTICE,0,"pid = %P exited with code %d!",pid,WEXITSTATUS(status)); 
		}
	}//end for

	return ;
}




