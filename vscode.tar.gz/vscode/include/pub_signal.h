#ifndef __MY_SIGNAL_H__
#define __MY_SIGNAL_H__

#include <stdio.h>
#include <unistd.h>


#endif