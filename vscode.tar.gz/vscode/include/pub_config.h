#ifndef __MY_CONFIG_H__
#define __MY_CONFIG_H__

#include <stdio.h>
#include <unistd.h>
void config();
#include <vector>
#include "pub_global.h"
using namespace std;
class CConfig
{
private:
        CConfig();
public:
    ~CConfig();
private:
    static CConfig *m_instance;
public:
    static CConfig *GetInstance(){
        if(m_instance == NULL)
        {
             m_instance = new CConfig();
             static delMemoryCConfig delCfg;

        }
        return m_instance;

    }
    class delMemoryCConfig{
        public:
        ~delMemoryCConfig(){
            if(CConfig::m_instance){
                delete CConfig::m_instance;
                CConfig::m_instance=NULL;
            }
        }
    };

    public:
    bool load(const char *pfileName);
    const char *GetString(const char *itemName);
    int GetInitDefualt(const char *itemName,int def);

    vector<pItemConfig> itemConfigList;

};




#endif