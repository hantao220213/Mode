#ifndef __PUB_STRING_H__
#define __PUB_STRING_H__

void Ltrim(char *string);
void Rtrim(char *string) ;

#endif
