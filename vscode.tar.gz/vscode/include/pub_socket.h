#ifndef __PUB_SOCKET_H__
#define __PUB_SOCKET_H__
#include <vector>
#include<sys/socket.h>
#include<sys/epoll.h>
#include <iostream>
using namespace std;
#define NGX_LISTEN_BACKLOG  511    //已完成连接队列
#define NGX_MAX_EVENTS      512    //epoll_wait一次最多接收这么多个事件

typedef struct   connect_s connect_t,*lpconnect_t ;
typedef struct  listen_s listen_t,*lplisten_t;

typedef class CSockt  CSockt;

typedef void (CSockt::*event_handler_pt)(lpconnect_t c); //成员函数指针

struct listen_s
{
   int          fd; //监听套接字文件描述符
   int          port; //端口
    lpconnect_t connections; //指向连接池中的一个连接的指针;
};
struct connect_s
{
    int             fd;//套接字文件描述符
    lplisten_t      listening;//一个连接被分配给一个监听套接字，指针指向监听套接字对应的那个lpconnect_t的首地址

    unsigned        instance:1;//【位域】0-有效，1-失效(处理连接是否过期标志)
    uint64_t        iCurrsequence;//引入的一个序号，每次分配出去时+1，检测错包废包
    struct sockaddr s_sockaddr;//保存对方地址信息
    uint8_t         r_ready;//读准备标志
    uint8_t         w_ready;//写准备标志

    event_handler_pt rhandler; //读事件处理方法
    event_handler_pt whandler; //写事件处理方法
    
    lpconnect_t data; //*next
};

class CSockt
{   
public:
   CSockt();
   virtual ~CSockt();
public:
   virtual bool Initialize();

private:
    void ReadConfig(); //读取配置文件信息
    bool open_listening_socket(); //监听必须的端口【支持多个端口】
    void close_listening_socket(); //关闭监听端口
    bool setnoblocking(int sockfd); //设置非阻塞io

    lpconnect_t get_connection(int sockfd); //从连接池中获取一个空闲连接
    void free_connection(lpconnect_t c); //归还参数c所代表的连接到到连接池中

    //连接处理
    void event_accept(lpconnect_t oldc); //建立新连接
    void close_accept_connection(lpconnect_t newconnection); //关闭建立的连接

    //接收处理
    void wait_rquest_handler(lpconnect_t newconn); //接收连接请求数据


public:
    int epoll_init(); //初始化
    int epoll_add_event(int fd,int readevent,int writeevent, int eventtype , lpconnect_t c,int otherflag ); //增加epoll事件
    int epoll_process_events(int timer); //epoll等待处理事件
    
private:
    int         m_WorkConnections; //epoll连接的最大数量
    int         m_ListenPortCount; //监听端口的数量;
    int         m_epollhandle; //epoll_create返回的句柄

    lpconnect_t m_pconnctions; //连接池首地址
    lpconnect_t m_pfree_connctions;//空闲连接链表头
    
    
    int         m_connctions_n; //当前进程中所有连接对象的总数【连接池大小】
    int         m_free_connctions_n; //连接池中可用连接总数                                                               

    std::vector<lplisten_t>m_ListenSocketList; // 监听套接字队列
    struct epoll_event m_events[NGX_MAX_EVENTS]; //用于在epoll_wait()中承载返回的所发生的事件
   

};




#endif