#ifndef __PUB_GLBLDEF_H__
#define __PUB_GLBLDEF_H__
#include "pub_string.h"
#include <stdint.h>
#include<stdio.h>
#include<string>
#include<unistd.h>
#include<sys/types.h>
#include<signal.h>
#include "pub_socket.h"
using namespace std;

typedef struct {
    int log_level;
    int fd;
}log_t;
extern log_t ngx_log;

extern pid_t ngx_pid;
extern pid_t parent_pid;
extern int g_daemonzed;
extern char **g_os_argv;
extern char *g_penvmem;
extern int g_environlen;
extern int argvlen;
extern int g_os_argc;
extern int process_type; //进程 master or work
extern CSockt g_socket;




typedef struct 
{
    /* data */
    char itemName[50];

    char itemValue[512];
}ItemConfig,*pItemConfig;


void init_setproctitle();
void set_proctitle(const char *title);

void   ngx_log_init();
void   ngx_log_stderr(int err, const char *fmt, ...);
void   ngx_log_error_core(int level,  int err, const char *fmt, ...);

u_char *ngx_log_errno(u_char *buf, u_char *last, int err);
u_char *ngx_slprintf(u_char *buf, u_char *last, const char *fmt, ...);
u_char *ngx_vslprintf(u_char *buf, u_char *last,const char *fmt,va_list args);
static u_char * ngx_sprintf_num(u_char *buf, u_char *last, uint64_t ui64, u_char zero, uintptr_t hexadecimal, uintptr_t width);


int init_signals();

void master_process_cycle();


extern sig_atomic_t work_precess_reap; 
                                  
int project_daemon();

void process_event_and_timers(); // 处理网络事件和定时事件




#endif