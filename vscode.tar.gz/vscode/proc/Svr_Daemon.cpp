#include"pub_global.h"
#include "pub_log.h"
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>

int project_daemon(){
    switch (fork())
    {
    case 0:
        ngx_log_error_core(NGX_LOG_INFO,errno,"创建守护进程成功 ");
        break;
    case -1:
        ngx_log_error_core(NGX_LOG_EMERG,errno," 创建守护进程失败");
        return -1;
        break;
    
    default:
        return 1;
        break;
    }

    parent_pid = ngx_pid;
    ngx_pid =getpid();

    //脱离终端
    if(setsid() == -1){
        ngx_log_error_core(NGX_LOG_EMERG,errno," setid 脱离终端失败");
        return -1;
    }
    
    //设置为0
    umask(0);

    //打开黑洞设备，重定向标准输出，输入
    int fd = open("/dev/null",O_RDWR);
    if(fd < 0){
        ngx_log_error_core(NGX_LOG_EMERG,errno," open /dev/null failed");
        return -1;
    }
    if(dup2(fd,STDIN_FILENO) ==-1){
        ngx_log_error_core(NGX_LOG_EMERG,errno," 重定向输入到/dev/null 失败");
        return -1;
    }
    if(dup2(fd,STDOUT_FILENO) ==-1){
        ngx_log_error_core(NGX_LOG_EMERG,errno,"重定向输出到/dev/null 失败");
        return -1;
    }
    if(fd > STDERR_FILENO){
        if(close(fd) ==-1){
            ngx_log_error_core(NGX_LOG_EMERG,errno," 关闭打开设备/dev/null 失败");
            return -1;
        }
    }
    return 0;
}