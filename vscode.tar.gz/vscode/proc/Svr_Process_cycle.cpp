#include<signal.h>
#include<string.h>
#include <sys/types.h>
#include <unistd.h>

#include "pub_global.h"
#include "pub_log.h"
#include "pub_config.h"
#include "pub_socket.h"

static char master_precess[]="master process";

static void start_work_process(int process_num);
static int spwn_work_process(int procNum,const char *pprocName);
static void work_process_init();
static void work_process_cycle(int procNum,const char *pprocName);

void master_process_cycle(){
   sigset_t set;
    sigemptyset(&set);

    sigaddset(&set, SIGCHLD);     //子进程状态改变
    sigaddset(&set, SIGALRM);     //定时器超时
    sigaddset(&set, SIGIO);       //异步I/O
    sigaddset(&set, SIGINT);      //终端中断符
    sigaddset(&set, SIGHUP);      //连接断开
    sigaddset(&set, SIGUSR1);     //用户定义信号
    sigaddset(&set, SIGUSR2);     //用户定义信号
    sigaddset(&set, SIGWINCH);    //终端窗口大小改变
    sigaddset(&set, SIGTERM);     //终止
    sigaddset(&set, SIGQUIT);     //终端退出符

    if(sigprocmask(SIG_BLOCK,&set,NULL) ==-1)
    {
        ngx_log_error_core(NGX_LOG_ALERT,errno,"master_process_cycle 时 sigprocmask 失败！！！,程序继续执行......");
       
    }

    int tsz = sizeof(master_precess)/sizeof(char);
    int sz = tsz+argvlen;
    if(sz < 1024){
        char title[1024]={0};
        memcpy(title,master_precess,tsz);
        strcat(title," ");
        for (size_t i = 0; i < g_os_argc; i++)
        {
           strcat(title,g_os_argv[i]);
        }
        set_proctitle(title);       
    }

    CConfig *pcfg = CConfig::GetInstance();
    int process_num = pcfg->GetInitDefualt("WorkerProcesses",1);

    ngx_log_stderr(0,"process_num (%d) succed!",process_num);
    //创建子进程
    start_work_process(process_num);


    //父进程
    sigemptyset(&set);

    for(;;){

        sigsuspend(&set);//阻塞在这里，等待一个信号，此时进程是挂起的，不占用cpu时间，只有收到信号才会被唤醒；
       
        ngx_log_error_core(0,0," 父进程 【%d】",ngx_pid);
    }


}

static void start_work_process(int process_num){
    int fpid=-1;
    size_t i;
    for ( i = 0; i < process_num; i++)
    {
       fpid = spwn_work_process(i,"work process") ;
       
    }


    return ;
}
static int  spwn_work_process(int procNum,const char *pprocName){

    pid_t fpid=-1;
    fpid = fork();
    
    ngx_log_stderr(0,"子进程id :  %d ,pid [%d]",getpid(),fpid);
    
    switch (fpid)
    {
    case -1:
        ngx_log_error_core(NGX_LOG_ALERT,errno,"fork 创建子进程 [%d] [%s] 失败",procNum,pprocName);
        break;
    case 0:
        ngx_log_stderr(0,"创建子进程成功 :  %d ,process name  [%s]",getpid(),pprocName);
        parent_pid =ngx_pid;
        ngx_pid = getpid();
        work_process_cycle(procNum,pprocName);
        break;
    default:
         ngx_log_error_core(0,0," spwn_work_process 父进程 ");
        break;
    }

    return fpid ;
}

//开启屏蔽信号量,以及初始化子进程连接池
static void work_process_init(){
    sigset_t set;

    sigemptyset(&set);
    if(sigprocmask(SIG_SETMASK,&set,NULL) ==-1){
        ngx_log_error_core(NGX_LOG_ALERT,errno," sigprocmask 开启屏蔽信号失败");
    }

    //初始化epoll，往监听socket上增加监听事件
    g_socket.epoll_init();

    return;

}
//worker子进程的功能函数，（无限循环【处理网络事件】）
static void work_process_cycle(int procNum,const char *pproName){
    process_type =PROCESS_WORK;
    work_process_init();
    set_proctitle(pproName);
    ngx_log_error_core(NGX_LOG_NOTICE,0,"%s %P 启动并开始运行......!",pproName,ngx_pid); 
    for(;;){

        //处理网络事件
        process_event_and_timers();
    }

}