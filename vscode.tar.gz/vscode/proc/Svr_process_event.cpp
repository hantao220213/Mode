#include "pub_global.h"
#include "pub_socket.h"
#include "pub_log.h"

//处理网络事件
void process_event_and_timers()
{
    g_socket.epoll_process_events(-1);//-1表示一直等待
}
